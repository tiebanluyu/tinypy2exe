for i in range(100):
    if i<60:
        print(i)