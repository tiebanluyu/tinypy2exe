import os
import shutil
from level2 import execute_code
def level3(code,des):
    with open(des+"/code.py","w") as f:
        f.write(code)
    
    os.system(f"cd {des}&& pyinstaller code.py")    
    
    # Usage example:
    
    exceptions = ["code.exe", "base_library.zip"]
    des=des+"/code"
    for filename in os.listdir(des):
        if filename.startswith("python"):
            exceptions.append(filename)
    delete_files_except(des, exceptions)
    compresszip(des)
def delete_files_except(des, exceptions):
    for filename in os.listdir(des):
        if filename not in exceptions:
            filepath = os.path.join(des, filename)
            if os.path.isdir(filepath):
                shutil.rmtree(filepath)
            else:
                os.remove(filepath)
def compresszip(des):
    #des=des+"/code"
    #breakpoint()
    import zipfile
    import uncompyle6
    

    # Unzip the base_library.zip
    with zipfile.ZipFile(des+'/base_library.zip', 'r') as zip_ref:
        zip_ref.extractall(des)
    """
    # Convert all pyc files to py files
    for pyc_file in return_pyc_files(des):
        py_file = pyc_file[:-1]

        import os
        print(f"uncompyle6 {des+'/'+pyc_file} >> {des+'/'+py_file} ")
        os.system(f"uncompyle6 {des+'/'+pyc_file} >> {des+'/'+py_file} ")

    """
    os.remove(des+"//base_library.zip")
    #os.system("del {des}//*.pyc")    
    """       
    # Zip all py files into base_library.zip
    with zipfile.ZipFile(des+'/base_library.zip', 'w') as zipf:
        for py_file in return_py_files(des):
            zipf.write(py_file)"""
def return_pyc_files(des):
    py_files = []
    for filename in os.listdir(des):
        if filename.endswith(".pyc"):
            py_files.append(filename)
            print(filename)
    return py_files
def return_py_files(des):
    py_files = []
    for filename in os.listdir(des):
        if filename.endswith(".py"):
            py_files.append(filename)
            
    return py_files
            
