#include<stdlib.h>
int main(){
    system("start /wait /b main.bat");
    return 1;

}