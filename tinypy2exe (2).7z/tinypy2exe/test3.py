
while 1:
    exec(input())